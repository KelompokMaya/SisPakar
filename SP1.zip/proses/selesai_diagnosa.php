<?php
session_start();
 $_SESSION['pertanyaan']=0;
    header("Location: ../index.php"); ?>